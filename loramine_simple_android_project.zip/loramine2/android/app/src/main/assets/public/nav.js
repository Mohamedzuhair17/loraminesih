(function () {
  "use strict";

  var SCREENS = [
    { file: "login_screen.html", label: "Login" },
    { file: "transition_secure_handshake.html", label: "Loading" },
    { file: "dashboard.html", label: "Dashboard" },
    { file: "alerts_list.html", label: "Alerts" },
    { file: "worker_status.html", label: "Worker Status" },
    { file: "emergency_sos_screen.html", label: "Emergency SOS" }
  ];

  var CURRENT = (location.pathname.split("/").pop() || "dashboard.html");

  function go(file) { location.href = file; }
  function closestClickable(el) {
    return el.closest("button, a, [role='button'], .cursor-pointer") || el;
  }
  function textOf(el) { return (el.textContent || "").trim().toLowerCase(); }

  // Auto-advance the loading/transition screen
  if (CURRENT === "transition_secure_handshake.html") {
    setTimeout(function () { go("dashboard.html"); }, 1800);
  }

  // Bottom nav / icon wiring
  var ICON_TARGETS = {
    dashboard: "dashboard.html",
    notifications: "alerts_list.html",
    engineering: "worker_status.html",
    emergency: "emergency_sos_screen.html",
    arrow_back: "__back__",
    chevron_left: "__back__",
    close: "__back__"
  };

  document.querySelectorAll(".material-symbols-outlined").forEach(function (icon) {
    var name = (icon.getAttribute("data-icon") || textOf(icon)).trim();
    var target = ICON_TARGETS[name];
    if (!target) return;
    var clickable = closestClickable(icon);
    clickable.style.cursor = "pointer";
    clickable.addEventListener("click", function (e) {
      e.preventDefault();
      if (target === "__back__") {
        if (history.length > 1) history.back();
        else go("dashboard.html");
      } else {
        go(target);
      }
    });
  });

  // Text-based wiring
  var TEXT_RULES = [
    { match: "log in", target: "transition_secure_handshake.html" },
    { match: "sign in", target: "transition_secure_handshake.html" },
    { match: "send rescue team", target: "emergency_sos_screen.html" },
    { match: "call worker", target: "emergency_sos_screen.html" }
  ];

  document.querySelectorAll("button, a, [role='button'], .cursor-pointer").forEach(function (el) {
    var t = textOf(el);
    if (!t) return;
    for (var i = 0; i < TEXT_RULES.length; i++) {
      if (t.indexOf(TEXT_RULES[i].match) !== -1) {
        var target = TEXT_RULES[i].target;
        el.style.cursor = "pointer";
        el.addEventListener("click", function (e) { e.preventDefault(); go(target); });
        break;
      }
    }
  });

  // Floating "Screens" jump menu
  function buildMenu() {
    var btn = document.createElement("div");
    btn.textContent = "\u2630";
    btn.style.cssText =
      "position:fixed;top:10px;right:10px;width:34px;height:34px;border-radius:50%;" +
      "background:rgba(0,0,0,0.55);color:#fff;display:flex;align-items:center;" +
      "justify-content:center;font-size:16px;z-index:99999;cursor:pointer;" +
      "font-family:sans-serif;backdrop-filter:blur(4px);";

    var panel = document.createElement("div");
    panel.style.cssText =
      "position:fixed;top:50px;right:10px;max-height:80vh;overflow-y:auto;" +
      "background:#14171a;border:1px solid rgba(255,255,255,0.15);border-radius:10px;" +
      "padding:8px;display:none;z-index:99999;min-width:180px;" +
      "box-shadow:0 8px 24px rgba(0,0,0,0.5);font-family:sans-serif;";

    SCREENS.forEach(function (s) {
      var item = document.createElement("div");
      item.textContent = s.label;
      var active = s.file === CURRENT;
      item.style.cssText =
        "padding:8px 10px;border-radius:6px;color:" + (active ? "#4edea3" : "#e1e2e7") +
        ";font-size:13px;cursor:pointer;font-weight:" + (active ? "700" : "400") + ";";
      item.addEventListener("mouseenter", function () { item.style.background = "rgba(255,255,255,0.08)"; });
      item.addEventListener("mouseleave", function () { item.style.background = "transparent"; });
      item.addEventListener("click", function () { go(s.file); });
      panel.appendChild(item);
    });

    btn.addEventListener("click", function () {
      panel.style.display = panel.style.display === "none" ? "block" : "none";
    });

    document.body.appendChild(btn);
    document.body.appendChild(panel);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", buildMenu);
  } else {
    buildMenu();
  }
})();

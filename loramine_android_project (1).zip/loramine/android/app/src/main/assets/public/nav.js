(function () {
  "use strict";

  var SCREENS = [
    { file: "splash_screen.html", label: "Splash" },
    { file: "login_screen.html", label: "Login" },
    { file: "role_selection_screen.html", label: "Role Selection" },
    { file: "worker_dashboard.html", label: "Worker Dashboard" },
    { file: "mine_overview.html", label: "Mine Overview" },
    { file: "digital_twin.html", label: "Digital Twin" },
    { file: "hazard_monitoring.html", label: "Hazard Monitoring" },
    { file: "worker_tracking.html", label: "Worker Tracking" },
    { file: "ai_risk_analysis.html", label: "AI Risk Analysis" },
    { file: "alert_center.html", label: "Alert Center" },
    { file: "incident_details.html", label: "Incident Details" },
    { file: "emergency_sos_active.html", label: "Emergency SOS" },
    { file: "rescue_route_planning.html", label: "Rescue Route Planning" },
    { file: "sensor_details.html", label: "Sensor Details" },
    { file: "communication_network.html", label: "Communication Network" },
    { file: "profile_settings.html", label: "Profile Settings" }
  ];

  var CURRENT = (location.pathname.split("/").pop() || "worker_dashboard.html");

  function go(file) {
    location.href = file;
  }

  function closestClickable(el) {
    return el.closest("button, a, [role='button'], .cursor-pointer") || el;
  }

  function textOf(el) {
    return (el.textContent || "").trim().toLowerCase();
  }

  // ---- 1. Splash screen auto-advance ----
  if (CURRENT === "splash_screen.html") {
    setTimeout(function () { go("login_screen.html"); }, 1800);
  }

  // ---- 2. Bottom nav icon wiring (home / mine / alerts / map / profile) ----
  var ICON_TARGETS = {
    home: "worker_dashboard.html",
    settings_input_component: "mine_overview.html",
    notifications: "alert_center.html",
    explore: "worker_tracking.html",
    person: "profile_settings.html",
    emergency: "emergency_sos_active.html",
    sensors: "sensor_details.html",
    warning: "hazard_monitoring.html",
    group: "worker_tracking.html",
    engineering: "digital_twin.html",
    precision_manufacturing: "digital_twin.html",
    directions_run: "rescue_route_planning.html",
    chat: "communication_network.html",
    arrow_back: "__back__",
    chevron_left: "__back__",
    close: "__back__"
  };

  document.querySelectorAll(".material-symbols-outlined").forEach(function (icon) {
    var name = (icon.getAttribute("data-icon") || textOf(icon)).trim();
    var target = ICON_TARGETS[name];
    if (!target) return;
    var clickable = closestClickable(icon);
    clickable.style.cursor = "pointer";
    clickable.addEventListener("click", function (e) {
      e.preventDefault();
      if (target === "__back__") {
        if (history.length > 1) history.back();
        else go("worker_dashboard.html");
      } else {
        go(target);
      }
    });
  });

  // ---- 3. Text-based wiring for key buttons/cards ----
  var TEXT_RULES = [
    { match: "sign in", target: "role_selection_screen.html" },
    { match: "worker", target: "worker_dashboard.html" },
    { match: "supervisor", target: "mine_overview.html" },
    { match: "control room", target: "mine_overview.html" },
    { match: "rescue team", target: "rescue_route_planning.html" },
    { match: "sos emergency", target: "emergency_sos_active.html" }
  ];

  document.querySelectorAll("button, a, [role='button'], .cursor-pointer").forEach(function (el) {
    var t = textOf(el);
    if (!t) return;
    for (var i = 0; i < TEXT_RULES.length; i++) {
      if (t.indexOf(TEXT_RULES[i].match) !== -1) {
        var target = TEXT_RULES[i].target;
        el.style.cursor = "pointer";
        el.addEventListener("click", function (e) {
          e.preventDefault();
          go(target);
        });
        break;
      }
    }
  });

  // ---- 4. Floating "Screens" menu (always-available jump to any screen) ----
  function buildMenu() {
    var btn = document.createElement("div");
    btn.textContent = "\u2630";
    btn.setAttribute("aria-label", "All screens");
    btn.style.cssText =
      "position:fixed;top:10px;right:10px;width:34px;height:34px;border-radius:50%;" +
      "background:rgba(0,0,0,0.55);color:#fff;display:flex;align-items:center;" +
      "justify-content:center;font-size:16px;z-index:99999;cursor:pointer;" +
      "font-family:sans-serif;backdrop-filter:blur(4px);";

    var panel = document.createElement("div");
    panel.style.cssText =
      "position:fixed;top:50px;right:10px;max-height:80vh;overflow-y:auto;" +
      "background:#14171a;border:1px solid rgba(255,255,255,0.15);border-radius:10px;" +
      "padding:8px;display:none;z-index:99999;min-width:200px;" +
      "box-shadow:0 8px 24px rgba(0,0,0,0.5);font-family:sans-serif;";

    SCREENS.forEach(function (s) {
      var item = document.createElement("div");
      item.textContent = s.label;
      var active = s.file === CURRENT;
      item.style.cssText =
        "padding:8px 10px;border-radius:6px;color:" + (active ? "#4edea3" : "#e1e2e7") +
        ";font-size:13px;cursor:pointer;font-weight:" + (active ? "700" : "400") + ";";
      item.addEventListener("mouseenter", function () { item.style.background = "rgba(255,255,255,0.08)"; });
      item.addEventListener("mouseleave", function () { item.style.background = "transparent"; });
      item.addEventListener("click", function () { go(s.file); });
      panel.appendChild(item);
    });

    btn.addEventListener("click", function () {
      panel.style.display = panel.style.display === "none" ? "block" : "none";
    });

    document.body.appendChild(btn);
    document.body.appendChild(panel);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", buildMenu);
  } else {
    buildMenu();
  }
})();

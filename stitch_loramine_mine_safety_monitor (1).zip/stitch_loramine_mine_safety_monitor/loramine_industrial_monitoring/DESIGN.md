---
name: LORAMINE Industrial Monitoring
colors:
  surface: '#f8f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f8f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#424752'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#727783'
  outline-variant: '#c2c6d4'
  surface-tint: '#005db7'
  primary: '#004d99'
  on-primary: '#ffffff'
  primary-container: '#1565c0'
  on-primary-container: '#dae5ff'
  inverse-primary: '#a9c7ff'
  secondary: '#4c616c'
  on-secondary: '#ffffff'
  secondary-container: '#cfe6f2'
  on-secondary-container: '#526772'
  tertiary: '#813900'
  on-tertiary: '#ffffff'
  tertiary-container: '#a64c00'
  on-tertiary-container: '#ffdece'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#a9c7ff'
  on-primary-fixed: '#001b3d'
  on-primary-fixed-variant: '#00468c'
  secondary-fixed: '#cfe6f2'
  secondary-fixed-dim: '#b4cad6'
  on-secondary-fixed: '#071e27'
  on-secondary-fixed-variant: '#354a53'
  tertiary-fixed: '#ffdbc9'
  tertiary-fixed-dim: '#ffb68c'
  on-tertiary-fixed: '#321200'
  on-tertiary-fixed-variant: '#753400'
  background: '#f8f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-xl:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  status-number:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 48px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  touch-target-min: 48px
  gutter: 16px
  margin-mobile: 20px
  margin-desktop: 40px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
---

## Brand & Style

The design system is engineered for high-stakes industrial environments where clarity, speed of recognition, and physical safety are paramount. The brand personality is authoritative, vigilant, and utilitarian. It prioritizes information density for rapid decision-making while maintaining an "uncluttered" interface that reduces cognitive load during emergencies.

The visual style follows a **Corporate / Modern** aesthetic with a lean toward **High-Visibility Industrialism**. It utilizes generous whitespace, clear structural divisions, and a highly disciplined color application to ensure that safety-critical data is never obscured by decorative elements. The interface must feel like a reliable tool—stable, responsive, and indestructible.

## Colors

The palette is optimized for legibility under varying light conditions found in mining operations (harsh artificial light or low-light office environments). 

- **Primary Blue (#1565C0):** Used for primary actions, navigation states, and branding. It conveys professional stability.
- **Surface Neutrals:** Backgrounds use a very light gray (#F5F7F9) to reduce screen glare compared to pure white, while maintaining high contrast with text.
- **Status Colors:** These are non-negotiable. **Success Green** indicates "All Clear," **Warning Yellow** indicates "Caution/Maintenance," and **Danger Red** indicates "Immediate Hazard." These colors must be used sparingly and only to denote actual equipment or safety status.

## Typography

This design system utilizes **Inter** for its exceptional legibility and systematic character. To accommodate supervisors who may be wearing protective gear or viewing screens at arm's length, text sizes are intentionally larger than standard consumer apps.

- **Scale:** Avoid any font size below 14px.
- **Hierarchy:** Use font weight (Bold/Semi-bold) to differentiate between data labels and actual data values.
- **Numbers:** Since the app monitors telemetry, use tabular figures (monospaced numbers) where possible to ensure that changing values don't cause visual jitter in the UI.

## Layout & Spacing

The layout philosophy is based on a **Fluid Grid** with strict vertical rhythm to ensure tappability. 

- **Mobile:** A single-column layout is preferred for monitoring lists to prevent accidental taps. Horizontal margins are set to 20px to provide a comfortable "thumb-safe" zone.
- **Tablet/Desktop:** Content should transition to a multi-column dashboard card view. 
- **Touch Targets:** Every interactive element (buttons, toggles, list items) must have a minimum height of 48px. 
- **Spacing Rhythm:** Use a base-8 increment system. Padding inside cards should be a minimum of 24px (stack-lg) to keep data points distinct and readable.

## Elevation & Depth

To maintain an industrial, "flat-clear" look, this design system uses **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows.

- **Surface Levels:** The base background is the lowest level. Cards and containers sit one level above, using a pure white background with a subtle 1px border (#E0E6ED).
- **Active State:** Instead of a shadow, an active or "pressed" card should use a 2px Primary Blue border.
- **Modals/Alerts:** Only critical alerts should use a medium-diffusion shadow (15% opacity) to pull focus toward the center of the screen during emergencies.

## Shapes

The design system uses a **Soft** shape language. While sharp corners feel too aggressive, overly rounded "pill" shapes feel too consumer-oriented. 

- **Standard Radius:** 0.25rem (4px) for small components like checkboxes and small badges.
- **Large Radius:** 0.5rem (8px) for cards and primary action buttons.
- **Icons:** Use thick-stroke (2px minimum) geometric icons. Avoid thin or illustrative icons that might disappear against complex backgrounds.

## Components

### Buttons
- **Primary:** High-contrast Blue background with white text. Height: 56px for main actions.
- **Secondary:** White background with a 2px Blue border. 
- **Critical:** Danger Red background, reserved exclusively for "Stop," "Emergency," or "Evacuate" actions.

### Status Badges
Badges use a "Light-Fill" style: a 10% opacity background of the status color with high-contrast bold text of the same color (e.g., Light Red background with Dark Red text). This ensures the color is perceived without vibrating against the white card.

### Cards
Cards are the primary container for data. They must not contain more than 4 key data points. Titles should be in `label-xl` and values in `headline-md` or `status-number`.

### Inputs
Fields must have a permanent label (no floating labels that disappear). Use a thick 2px border for the focused state to ensure the supervisor knows exactly which field is active.

### Navigation
The bottom tab bar uses a 64px height to accommodate large icons and `label-md` text. Icons must be solid-fill when active to provide a clear visual indicator of the current location.